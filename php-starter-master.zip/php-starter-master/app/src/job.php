<!DOCTYPE html>
<html lang="en">
<body>
<?php include './header.php' ?>
    <?php include './nav.php' ?>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $pageName; ?></title>
    <link rel="stylesheet" href="style.css">
</head>

<h2>Job History</h2>
<p>Below is my job history, there are no IT related jobs at the 
    moment but as I grow this may be subject to change depending 
    on how I persue my career.</p>
    <h3>Groundskeep - AA Munroe Insurance, Greenwood</h3>
    <p>During the period of March 2018 - September 2018 I was hired 
        as a groundskeep for AA Munroe Insurance where I mowed their 
        lawn, used power equipment such as a pressure washer to clean 
        the building and a Weed Whacker to tend to the places the 
        lawn mower could not. During the autumn months I also raked 
        their leaves.</p>
    <h3>Associate Employee - Walmart, Greenwood</h3>
    <p>I was employed at Walmart during the period of 
        October 2019 - November 2020 where my official title was 
        "Store Standards", this meant that I took care of all the 
        dirty work that needed to be done around the facility, these 
        tasks include: getting carts from outside, carrying out or 
        pushing carts of product to the customers car if they could 
        not lift it themselves, going into our claims bin and 
        cleaning it out or adding merchandise to them. cleaning out 
        and throwing away rotten food, properly disposing of 
        cardboard and finding items in store for customers.</p>
    <h3>Front Desk Employee - 14 Wing Fitness and Sports Center, Greenwood</h3>
    <p>I was given the opportunity to work at 14 Wing Greenwood 
        during the period of March 2021 - Current. At this job I 
        oversee the facility by making sure people follow the rules, 
        are using equipment properly, selling memberships, replacing 
        paper towels and disinfectant spray when nessecary, cleaning 
        up and locking down the facility at night, sweeping out gym 
        floor, shutting down the electronics, cleaning the locker 
        rooms and most importantly, being a friendly face when you 
        enter the facility.</p>
        <a href="hidden.php">Return to Personal Items</a>
    <?php include './footer.php' ?>
</body>

</html>