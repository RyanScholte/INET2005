<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Contact Me</title>
</head>
<body>
    <?php include './header.php' ?>
    <?php include './nav.php' ?>
    
    <h2>Contact Me</h2>
    
    <p>If you're interested in collaboration or have any inquiries regarding my work or me personally, please feel free to reach out. I'm dedicated to responding promptly and ensuring a smooth communication process.</p>

    <p>You can connect with me through the following channels:</p>

    <ul class="contact-list">
        <li class="contact-item">
            <img src="instagram.png" alt="Instagram">
            <span><a href="https://instagram.com/ryan_scholte?igshid=NzZlODBkYWE4Ng%3D%3D&utm_source=qr">Instagram</a></span>
        </li>
       
        <li class="contact-item">
            <img src="gmail.png" alt="Gmail">
            <span><a href="mailto:revelsscholte@gmail.com">Gmail</a></span>
        </li>
    </ul>
    
    <?php include './footer.php' ?>
</body>
</html>