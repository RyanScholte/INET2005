<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Example Work</title>
</head>
<?php include './header.php' ?>
    <?php include './nav.php' ?>
    <body>
    <h3>Random Match</h3>
    <p>This is a file that is used to pick a name at random, this can be useful
        when you need to pick a single object or name in a large group, David has frequently used this to 
        select a student to do a presentation in class.
    </p>
    <p>Below is a link you can use to access the program yourself.</p>
    <a href="randommatch.php">Random Match</a>

    <h3>Add Programs</h3>
    <p>This is a file that I have created in order to add, edit and remove items from a list, 
        this list is specifically used for course organization and is drawing from a Database that was also set up in Docker using a php-starter-master container in order to run.
    </p>
    <p>Below is a link you can use to add items to the list.</p>
    <a href="addProgram.php">Add Program</a>

    <h3>Chat Room</h3>
    <p>This is a file that I have created in order to add, edit and remove items from a list, 
        this list is specifically used for course organization and is drawing from a Database that was also set up in Docker using a php-starter-master container in order to run.
    </p>
    <p>Below is a link you can use to go and chat.</p>
    <a href="chat.php">Go Chat!</a>
    
    <?php include './footer.php' ?>
</body>
</html>