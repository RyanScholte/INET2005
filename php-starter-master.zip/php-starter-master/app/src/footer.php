<link rel="stylesheet" href="style.css">
<?php
    echo '<footer><p>Nova Scotia Community College 2023</p></footer>'
?>