<style>
    header {
        text-align: center;
        background-color: #36454F;
        color: #F4F3EE;
    }

    h1 {
        display: inline-block;
        font-family: "Montserrat", sans-serif; 
    }
</style>

<header>
    <h1>Ryan Revels-Scholte</h1>
</header>