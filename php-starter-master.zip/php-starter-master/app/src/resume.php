<!DOCTYPE html>
<html lang="en">
<body>
<?php include './header.php' ?>
    <?php include './nav.php' ?>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $pageName; ?></title>
    <link rel="stylesheet" href="style.css">
</head>
<h2>My Resume</h2>
<img src="resume.png" alt="My Resume">
        <a href="hidden.php">Return to Personal Items</a>
    <?php include './footer.php' ?>
</body>

</html>