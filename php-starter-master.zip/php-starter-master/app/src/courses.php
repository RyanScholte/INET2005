<?php
$activePage = 'courses';
$pageName = 'My Courses';
include("conn.php");
?>
<!DOCTYPE html>
<html lang="en">
 
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $pageName; ?></title>
    <link rel="stylesheet" href="style.css">
</head>

 
<body>
    <?php include './header.php';
    include './nav.php';
    ?>
    <?php
        $conn = new mysqli($db_host, $db_user, $db_password, $db_name);
 
        $sql = 'SELECT c.title, c.description, CONCAT(C.COURSECODE, C.COURSENUM) AS COURSECODE, CONCAT(I.FIRSTNAME, " ", I.LASTNAME) AS INSTRUCTOR
        FROM course as c
        LEFT JOIN instructor as i
        ON c.Instructor = i.instructorid;';
   
   
        //TODO make better Query then run and display output
   
        if ($result = $conn->query($sql)) {
            while ($data = $result->fetch_object()) {
                $courses[] = $data;
            }
        }
   
        foreach ($courses as $c) {
            echo "<br>";
            echo '<H1 style="font-weight: bold; color:black">' . $c->title . '</H1>';
            echo "<br>";
            echo $c->COURSECODE;
            echo "<br>";
            echo $c->description;
            echo "<br>";
            echo '<p style="font-style: italic;color:green">' . $c->INSTRUCTOR . '</p>';
            echo "<br>";
            echo "<br>";
        }
 
    ?>
 <a href="login.php">Return to Login screen</a>
    <?php
    include './footer.php'
    ?>
</body>
 
</html>