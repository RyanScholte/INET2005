<?php
$db_host = "db";
$db_user = "root";
$db_password = "super_secret123?";
$db_name = "NSCCSchedule";
?>