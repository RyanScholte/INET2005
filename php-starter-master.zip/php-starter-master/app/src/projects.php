<?php
$activePage = 'projects';
$pageName = 'Projects';
include("conn.php");
?>
<!DOCTYPE html>
<html lang="en">
<body>
<?php include './header.php' ?>
    <?php include './nav.php' ?>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $pageName; ?></title>
    <link rel="stylesheet" href="style.css">
</head>

<h3>Project 1 - Blender Study</h3>
    <video width="640" height="360" controls>
        <source src="Donut_Render_1.mp4" type="video/mp4">
        Your browser does not support the video tag.
    </video>

<p>This is a 3D animation that I did for my COMM professor last year, we were tasked with 
    studying something relating to programming and IT, I was given the go ahead on modelling as it
    is frequently used in the gaming world.
</p>
<h3>What I learned</h3>
<p>Doing this project I learned the intricacies of 3D modelling, how to build meshes, create textures and 
    and most importantly got a good grasp on Blender.

    <h3>Project 2 - Challenge Nova Scotia</h3>
    <iframe width="560" height="315" src="https://www.youtube.com/embed/R_emlf4m2AM?si=J2b4-YD6_BJhb1hu" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
        <p>Challenge Nova Scotia is an annual challenge held by the gavernment of Nova Scotia where students of NSCC are tasked 
            with coming up with an idea to help a problem Nova Scotia is currently facing. This year we tackled Food Insecurity. 
        </p>
<h3>What I learned</h3>
<p>I learned how to work under stress in a small environment while also collaborating with various sources and teammates.
    As the Project Manager, I also learned how to make sure all group members were on task throughout the day.
</p>
    <?php include './footer.php' ?>
</body>

</html>