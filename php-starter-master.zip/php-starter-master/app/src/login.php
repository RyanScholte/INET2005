<?php
// Database connection
$db_host = "db";
$db_user = "root";
$db_password = "super_secret123?";
$db_name = `your_database`;

// Create connection
$conn = new mysqli($db_host, $db_user, $db_password, $db_name);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Function to sanitize input data
function sanitizeInput($data)
{
    return htmlspecialchars(strip_tags($data));
}

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = sanitizeInput($_POST['username']);
    $password = sanitizeInput($_POST['password']);
 
    // Query the database for the user
    $query = "SELECT * FROM users WHERE username='$username'";
    $result = $conn->query($query);
    if ($result && $result->num_rows > 0) {
        // Valid username, check the password
        $row = $result->fetch_assoc();
        if (password_verify($password, $row['password'])) {
            // Valid credentials, redirect to a success page
            header("Location: hidden.php");
            exit();
        }
    } 

    // Invalid credentials, display an error message
    $error_message = "Invalid username or password";

    die("Error: " . $conn->error);
} 

// Close the database connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Page</title>
</head>

<body>
    <?php include './header.php' ?>
    <?php include './nav.php' ?>
    <h2>Login</h2>

    <?php if (isset($error_message)) : ?>
        <p style="color: red;"><?php echo $error_message; ?></p>
    <?php endif; ?>

    <form method="post" action="login.php">
        <label for="username">Username:</label>
        <input type="text" name="username" required><br>

        <label for="password">Password:</label>
        <input type="password" name="password" required><br>

        <input type="submit" value="Login">
    </form>
    <?php include './footer.php' ?>
</body>

</html>