<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=<form, initial-scale=1.0">
    <title>Document</title>
    <style>
        label, textarea {
            display: block;
        }
    </style>
</head>
<body>
    <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
        <div>
            <label for="tarStrings">Enter comma separated values here:</label>
            <textarea name="tarStrings" id="tarStrings" name="stringsTextarea" cols="30" rows="10">
Bart Simpson,
Lisa Simpson,
Maggie Simpson,
Marge Simpson,
Homer Simpson,
Graggle Simpson,
Abraham Simpson</textarea>
        </div>
        <input type="submit" value="Go">
    </form>
<?php
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $listStrings = trim($_POST["tarStrings"]);
        
        $arrStrings = explode(",",$listStrings);
        shuffle($arrStrings);
         
        echo "<h1>The Winner is...<span id='winner'>".$arrStrings[0]."</span>!</h1>";
        echo "<ol>";
        foreach ($arrStrings as $str ){
            echo "<li>".$str."</li>";
        }
        echo "</ol>";
    }
?>
<a href="examples.php">Return to Example Work</a>
<?php include './footer.php' ?>
</body>
</html>