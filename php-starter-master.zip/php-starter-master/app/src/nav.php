
 <nav class='topnav'>
 <a <?php if(basename($_SERVER['PHP_SELF']) == 'about.php') echo "class='active'"; ?> href='./about.php'>Home</a>
	<a <?php if(basename($_SERVER['PHP_SELF']) == 'contact.php') echo "class='active'"; ?> href='./contact.php'>Contact</a>
    <a <?php if(basename($_SERVER['PHP_SELF']) == 'projects.php') echo "class='active'"; ?> href='./projects.php'>Projects</a>
	<a <?php if(basename($_SERVER['PHP_SELF']) == 'examples.php') echo "class='active'"; ?> href='./examples.php'>Example Work</a>
	<a <?php if(basename($_SERVER['PHP_SELF']) == 'login.php') echo "class='active'"; ?> href='./login.php'>Login</a>
</nav> 
    
    