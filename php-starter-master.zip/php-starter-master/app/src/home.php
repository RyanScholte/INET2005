<?php
$activePage = 'home';
$pageName = 'Home';
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <?php include './header.php' ?>
    <!-- <nav class="topnav">
        <a class="active" href="#home">Home</a>
        <a href="#news">News</a>
        <a href="#contact">Contact</a>
        <a href="#about">About</a>
    </nav> -->
    <?php include './nav.php' ?>
    <h2><b>About Me</b></h2>
    <p>Hello there! I'm Ryan Revels-Scholte, a passionate and creative 
        individual with a love for technology and design. I thrive on 
        turning complex ideas into simple, elegant solutions. My journey 
        in the world of IT Programming has equipped me with a 
        diverse set of skills that blend both networking and programming.</p>
    <h2><b>What I Do</b></h2>
    <p>I bring a unique blend of technical proficiency and artistic 
        flair. My goal is to create not just functional solutions but 
        experiences that leave a lasting impression.</p>
    <h2><b>My Approach</b></h2>
    <p>I believe in the power of collaboration and continuous 
        learning. Every project is an opportunity to explore new 
        ideas and refine my skills. I enjoy working closely with 
        clients and colleagues to understand their vision and bring 
        it to life through innovative and user-friendly solutions.</p>
    <h2><b>Why Work With Me</b></h2>
    <p>
        <li><b>Innovative Solutions: </b>I love pushing boundaries 
        and thinking outside the box to deliver solutions that stand 
        out.</li>
        <li><b>Attention to Detail: </b>From the big picture to the 
        smallest details, I take pride in delivering work that is 
        polished and professional.</li>
        <li><b>Adaptability: </b>In a rapidly evolving IT world, 
        I embrace change and stay ahead of the curve to provide 
        cutting-edge solutions.</li>
    </p>
    <h2><b>Let's Connect</b></h2>
    <p>I'm always open to new opportunities and collaborations. 
        Whether you have a project in mind or just want to chat 
        about the latest trends in IT, I'd love to connect. Let's 
        create something amazing together!<br>
<br>
        Feel free to explore my portfolio to get a glimpse of my 
        work, and don't hesitate to reach out. I look forward to 
        the possibility of working together and bringing your 
        ideas to life!</p>
    

    <?php include './footer.php' ?>
</body>

</html>