<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <?php include './header.php' ?>
    <?php include './nav.php' ?>
    <h3>Resume</h3>
    <p>This is a file that is used to pick a name at random, this can be useful
        when you need to pick a single object or name in a large group, David has frequently used this to 
        select a student to do a presentation in class.
    </p>
    <p>Below is a link you can use to view my resume.</p>
    <a href="resume.php">View Resume</a>

    <h3>Job History</h3>
    <p>This is a file that I have created in order to add, edit and remove items from a list, 
        this list is specifically used for course organization and is drawing from a Database that was also set up in Docker using a php-starter-master container in order to run.
    </p>
    <p>Below is a link you can use to view my job history.</p>
    <a href="job.php">Job History</a>

    <h3>Courses</h3>
    <p>This is a file that I have created in order to add, edit and remove items from a list, 
        this list is specifically used for course organization and is drawing from a Database that was also set up in Docker using a php-starter-master container in order to run.
    </p>
    <p>Below is a link you can use to view my courses.</p>
    <a href="courses.php">View Courses</a>
    <?php include './footer.php' ?>
</body>

</html>
