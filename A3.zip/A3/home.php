<?php
//Server Connection Data
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "assignment3";

//Get form data and sanitize it
$title = $_POST['title'];
$first_name = $_POST['first_name'];
$last_name = $_POST['last_name'];
$street = $_POST['street'];
$city = $_POST['city'];
$province = $_POST['province'];
$postal_code = $_POST['postal_code'];
$country = $_POST['country'];
$phone = $_POST['phone'];
$email = $_POST['email'];
$newsletter = $_POST['newsletter'];

//Create a database connection
$db = new mysqli($servername, $username, $password, $dbname);

// Check for connection errors
if ($db->connect_error) {
    die("Connection failed: " . $db->connect_error);
}

//Assign newsletter a 1 or 0 depending on if they checked the box or not
if (isset($_POST['newsletter'])) {
    $newsletter = $_POST['newsletter'];
} else {
    $newsletter = 0;
}

//Create a Unique UserID
$user_id = uniqid();

//Create table if it doesn't exist
$createTableQuery = "CREATE TABLE IF NOT EXISTS `registered_users` (
    `user_id` INT AUTO_INCREMENT PRIMARY KEY,
    `title` VARCHAR(255),
    `first_name` VARCHAR(255),
    `last_name` VARCHAR(255),
    `street` VARCHAR(255),
    `city` VARCHAR(255),
    `province` VARCHAR(255),
    `postal_code` VARCHAR(10),
    `country` VARCHAR(255),
    `phone` VARCHAR(20),
    `email` VARCHAR(255),
    `newsletter` TINYINT(1)
)";

//Code to throw an error if the table cannot be created
if ($db->query($createTableQuery) === TRUE) {
    echo "Table created successfully.";
} else {
    echo "Error creating table: " . $db->error;
}

//Insert data into the database using prepared statements
$query = "INSERT INTO `registered_users` (`title`, `first_name`, `last_name`, `street`, `city`, `province`, `postal_code`, `country`, `phone`, `email`, `newsletter`) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
$stmt = $db->prepare($query);

//Populate the table
if ($stmt) {
    $stmt->bind_param("sssssssssss", $title, $first_name, $last_name, $street, $city, $province, $postal_code, $country, $phone, $email, $newsletter);

    if ($stmt->execute()) {
        $user_id = $stmt->insert_id;
        echo "Data inserted successfully";
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
} else {
    echo "Error: " . $db->error;
}

// Fetch all users from the database
$result = $db->query("SELECT * FROM registered_users");

if ($result->num_rows > 0) {
    echo "<h2>Users in the Database</h2>";
    echo "<table border='1'>";
    echo "<tr><th>User ID</th><th>Title</th><th>First Name</th><th>Last Name</th><th>Street</th><th>City</th><th>Province</th><th>Postal Code</th><th>Country</th><th>Phone</th><th>Email</th><th>Newsletter</th></tr>";

    while ($row = $result->fetch_assoc()) {
        echo "<tr><td>" . $row['user_id'] . "</td><td>" . $row['title'] . "</td><td>" . $row['first_name'] . "</td><td>" . $row['last_name'] . "</td><td>" . $row['street'] . "</td><td>" . $row['city'] . "</td><td>" . $row['province'] . "</td><td>" . $row['postal_code'] . "</td><td>" . $row['country'] . "</td><td>" . $row['phone'] . "</td><td>" . $row['email'] . "</td><td>" . $row['newsletter'] . "</td></tr>";
    }
    echo "</table>";
} else {
    echo "No users in the database.";
}

// Close the database connection
$db->close();
?>